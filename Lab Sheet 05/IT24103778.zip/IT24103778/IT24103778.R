setwd("C:\\Users\\IT24103778\\Desktop\\IT24103778")
getwd()

#01
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

#02
breaks <- seq(20, 70, length.out = 10)
hist(Delivery_Times$Delivery_Time, main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)", ylab = "Frequency",
     breaks = breaks, right = FALSE)

#03
#The histogram shows a shape that is slightly skewed to the right or positively skewed. This means that most delivery times are shorter, but there is a tail of a few longer delivery times.

#04
hist_data <- hist(Delivery_Times$Delivery_Time, breaks = breaks, right = FALSE, plot = FALSE)
counts <- hist_data$counts
breaks <- hist_data$breaks

cum_freq <- cumsum(counts)

ogive_points <- c(0, cum_freq)
ogive_breaks <- breaks

plot(ogive_breaks, ogive_points, type = "b", main = "Cumulative Frequency Polygon of Delivery Times",
     xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency",
     ylim = c(0, max(ogive_points)), pch = 16)

