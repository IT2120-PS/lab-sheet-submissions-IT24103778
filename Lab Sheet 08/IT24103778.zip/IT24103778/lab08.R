setwd("C:\\Users\\IT24103778\\Desktop\\IT24103778")

weights <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
weights <- weights$Weight.kg.

#01
pop_mean <- mean(weights)
pop_sd <- sd(weights)

#02
set.seed(123)

sample_means <- c()
sample_sds <- c()

for (i in 1:25) {
  sample_data <- sample(weights, size = 6, replace = TRUE)
  
  current_mean <- mean(sample_data)
  current_sd <- sd(sample_data)
  
  sample_means <- c(sample_means, current_mean)
  sample_sds <- c(sample_sds, current_sd)
}

print("Sample Means:")
print(sample_means)
print("Sample Standard Deviations:")
print(sample_sds)

#03
mean_of_sample_means <- mean(sample_means)
print(paste("Mean of Sample Means:", mean_of_sample_means))

sd_of_sample_means <- sd(sample_means)
print(paste("Standard Deviation of Sample Means (Standard Error):", sd_of_sample_means))

cat("\nRelationship to True Mean and Standard Deviation:\n")
cat(paste("1. The mean of the sample means (", round(mean_of_sample_means, 3), ") is approximately equal to the population mean (", round(pop_mean, 3), ").\n", sep = ""))
cat(paste("2. The standard deviation of the sample means (", round(sd_of_sample_means, 3), ") is the standard error of the mean. It's approximately equal to the population standard deviation divided by the square root of the sample size (", round(pop_sd / sqrt(6), 3), "). This illustrates the Central Limit Theorem.\n", sep = ""))

